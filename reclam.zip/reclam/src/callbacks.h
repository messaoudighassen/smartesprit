#include <gtk/gtk.h>

int i,j,k,l,m,n,h,d,o,q,r,c,g,p;

                                       
void
on_ajout_clicked                       (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button1_ajout_clicked               (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_ajou_ch_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_supp_ch_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_rech_ch_clicked                     (GtkWidget       *button,
                                        gpointer         user_data);

void
on_modi_ch_clicked                     (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_treeview5_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_actua_ch_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_treeview6_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_affi_ch_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data);


void
on_treeview3_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_supp_tree_ch_clicked                (GtkWidget       *objet,
                                        gpointer         user_data);


void
on_radiobutton11_poste_toggled         (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton12_poste_toggled         (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbutton14_groupe_toggled        (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbutton15_groupe_toggled        (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_button5_ok__clicked                 (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button6_rec_ouvrier_clicked         (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button7_ajouter_clicked             (GtkWidget       *objet,
                                        gpointer         user_data);
void
on_button7_quiter_ouv_clicked          (GtkWidget       *button,
                                        gpointer         user_data);


void
on_facebook_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_instagram_clicked                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_button56_clicked                    (GtkButton       *button,
                                        gpointer         user_data);
